# mathwrap
### Automatic Line-Breaking in Inline Math Mode

**Lee Yiu Sing**  
November 2026 — Version 1.2

## Introduction

By default, LaTeX strongly resists breaking lines inside inline mathematical expressions (`$...$`), frequently producing `Overfull \hbox` warnings when typesetting long variable lists, tensor indices, or multi-term equations. 

The **mathwrap** package addresses this globally through three complementary mechanisms:
1. **Active Inline Commas:** Allows zero-penalty line breaks after commas exclusively in standard inline math (`\textstyle`). Display equations and subscripts/superscripts are completely unaffected.
2. **Relaxed Operator Penalties:** Lowers `\binoppenalty` and `\relpenalty` to allow wrapping at operators like `+`, `=`, and `<`.
3. **Non-Destructive Stretch:** Slightly increases `\emergencystretch` so surrounding text can absorb line breaks smoothly without creating underfull lines.

## Installation

Place `mathwrap.sty` in your working directory, or install it into your local `texmf` tree:
```bash
TEXMFHOME/tex/latex/mathwrap/mathwrap.sty
```
*(Run `mktexlsr` or `texhash` afterward if required by your TeX distribution.)*

## Usage

Load the package in your document preamble:
```latex
\usepackage{mathwrap}
```

### Package Options

Each wrapping mechanism can be individually enabled or disabled. By default, all three are active (`[comma, penalties, stretch]`).

| Option | Behavior |
| :--- | :--- |
| `comma` / `nocomma` | Enables / disables line breaks after commas in inline math. |
| `penalties` / `nopenalties` | Lowers / preserves standard operator penalties (`\binoppenalty`, `\relpenalty`). |
| `stretch` / `nostretch` | Applies / skips the `\emergencystretch=1em` adjustment. |

Example: Wrap long lists, but leave operator penalties and paragraph stretch untouched:
```latex
\usepackage[nopenalties,nostretch]{mathwrap}
```

### Local Control & Commands

The package captures your document's original mathcode and penalty settings at `\AtBeginDocument`. You can dynamically restore or re-enable them mid-document:

- `\mathwrapOff` : Restores the original comma, `\binoppenalty`, `\relpenalty`, and `\emergencystretch`.
- `\mathwrapOn` : Re-activates the mathwrap settings (respecting your package options).

#### Semantic Wrapper Macros (Highly Recommended)
For elements that should *never* break (such as coordinates, closed intervals, or European decimals like `3,14159`), define lightweight semantic commands using `\ensuremath` and local scoping:

```latex
\newcommand{\tuple}[1]{\ensuremath{\mathwrapOff(#1)}}
\newcommand{\cint}[2]{\ensuremath{\mathwrapOff[#1, #2]}}

% Usage: The trajectory passes through \tuple{x_1, x_2, x_3} smoothly.
```

#### Environment Workarounds (e.g., TikZ)
Standard coordinate parsing in TikZ operates outside math mode and works normally. However, if an inline math expression inside a diagram node reacts unexpectedly to the active comma, you can wrap the environment:

```latex
\mathwrapOff
\begin{tikzpicture}
  \node at (0,0) {$f(x, y)$};
\end{tikzpicture}
\mathwrapOn
```

## Compatibility and Load Order

**Decimal-Comma Packages (`icomma`, `ncccomma`, `babel`):**  
`mathwrap` inspects the comma's mathcode at `\AtBeginDocument` and guards against infinite recursion. To ensure correct behavior, **always load `mathwrap` after** any package that configures math-mode commas.

## License

This package is released under the LaTeX Project Public License (LPPL), version 1.3c or later.